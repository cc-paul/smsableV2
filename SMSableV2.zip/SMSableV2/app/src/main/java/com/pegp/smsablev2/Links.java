package com.pegp.smsablev2;

import android.app.Application;

public class Links extends Application {
    String mainLink = "https://apps.project4teen.online/sms/";
    String smsReceiveAPI = mainLink + "php/contact_list.php";
    String history = mainLink + "php/list.php";
    String smsSent = mainLink + "php/issent.php";
}
