package com.pegp.smsablev2;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Log;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    TextView tvDeviceID,tvStartSending,tvSaveSettings,tvStartListening,tvCopyDeviceID;
    EditText etKeyword,etPHPLink;

    SharedPreferences sp;
    SharedPreferences.Editor editor;

    long time = System.currentTimeMillis();
    String deviceID,keyword,phpLink,messageIDs;
    Boolean isSMSActivated,isListeningActivated;

    Dialog singleSim,dualSim;

    ArrayList<Integer> subIDS = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        tvDeviceID = findViewById(R.id.tvDeviceID);
        tvStartSending = findViewById(R.id.tvStartSending);
        tvSaveSettings = findViewById(R.id.tvSaveSettings);
        tvStartListening = findViewById(R.id.tvStartListening);
        tvCopyDeviceID = findViewById(R.id.tvCopyDeviceID);

        etKeyword = findViewById(R.id.etKeyword);
        etPHPLink = findViewById(R.id.etPHPLink);

        sp = getSharedPreferences("key", Context.MODE_PRIVATE);
        editor = sp.edit();
        deviceID = sp.getString("deviceID", "-");
        keyword = sp.getString("keyword", "");
        phpLink = sp.getString("phpLink", "");
        messageIDs = sp.getString("messageIDs", "");

        if (messageIDs.equals("")) {
            editor.putString("messageIDs","0");
            editor.commit();
        }

        editor.putLong("dateInstalled", time);
        editor.commit();

        changeLabel();

        if (deviceID.equals("-")) {
            tvDeviceID.setText("" + time);
            editor.putString("deviceID","" + time);
            editor.commit();
        } else {
            tvDeviceID.setText(deviceID);
        }

        etKeyword.setText(keyword);
        etPHPLink.setText(phpLink);

        AlertDialog.Builder oneSimBuilder = new AlertDialog.Builder(this);
        oneSimBuilder
                .setTitle("Reminder")
                .setMessage("You only have 1 SIM Card activated. We will use this to send SMS, make sure it has a load. Proceed?")
                .setPositiveButton("OK", (dialog, id) -> {
                    startSMSService(subIDS.get(0),true);
                    singleSim.dismiss();
                })
                .setNegativeButton("Cancel", (dialog, id) -> {
                    singleSim.dismiss();
                });
        singleSim = oneSimBuilder.create();

        AlertDialog.Builder twoSimBuilder = new AlertDialog.Builder(this);
        twoSimBuilder
                .setTitle("Reminder")
                .setMessage("Select SIM that has a load and you want to set as SMS Sender")
                .setPositiveButton("SIM 1", (dialog, id) -> {
                    startSMSService(subIDS.get(0),true);
                    dualSim.dismiss();
                })
                .setNegativeButton("SIM 2", (dialog, id) -> {
                    startSMSService(subIDS.get(1),true);
                    dualSim.dismiss();
                });
        dualSim = twoSimBuilder.create();

        tvStartSending.setOnClickListener(view -> {
            PermissionListener permissionlistener = new PermissionListener() {
                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
                @Override
                public void onPermissionGranted() {
                    /* 1st check if there is a sim in sim2 if none use any available */
                    subIDS.clear();

                    SubscriptionManager subscriptionManager = SubscriptionManager.from(getApplicationContext());
                    if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }

                    List<SubscriptionInfo> subsInfoList = subscriptionManager.getActiveSubscriptionInfoList();
                    for (SubscriptionInfo subscriptionInfo : subsInfoList) {
                        int id = subscriptionInfo.getSubscriptionId();
                        subIDS.add(id);
                    }

                    if (subIDS.size() == 1) {
                        if (isSMSActivated) {
                            startSMSService(0,false);
                        } else {
                            singleSim.show();
                        }
                    } else if (subIDS.size() == 2) {
                        if (isSMSActivated) {
                            startSMSService(0,false);
                        } else {
                            dualSim.show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "No SIM Card attached", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                    Toast.makeText(MainActivity.this, "Some permissions were denied. Unable to use this function", Toast.LENGTH_LONG).show();
                }
            };

            new TedPermission(this)
                    .setPermissionListener(permissionlistener)
                    .setDeniedMessage("SMS Permission is required.\n\nPlease turn on permissions at [Setting] > [Permission]")
                    .setPermissions(Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.FOREGROUND_SERVICE, Manifest.permission.READ_SMS)
                    .check();
        });

        tvStartListening.setOnClickListener(view -> {
            if (etKeyword.getText().toString().equals("") || etPHPLink.getText().toString().equals("")) {
                Toast.makeText(this,"Please fill in all fields in Incoming Message Settings",Toast.LENGTH_LONG).show();
            } else {
                PermissionListener permissionlistener = new PermissionListener() {
                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
                    @Override
                    public void onPermissionGranted() {
                        isListeningActivated = sp.getBoolean("isListeningActivated",false);
                        isListeningActivated = !isListeningActivated;
                        startListening(isListeningActivated);
                    }

                    @Override
                    public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                        Toast.makeText(MainActivity.this, "Some permissions were denied. Unable to use this function", Toast.LENGTH_LONG).show();
                    }
                };

                new TedPermission(this)
                        .setPermissionListener(permissionlistener)
                        .setDeniedMessage("SMS Permission is required.\n\nPlease turn on permissions at [Setting] > [Permission]")
                        .setPermissions(Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS)
                        .check();
            }
        });

        tvSaveSettings.setOnClickListener(view -> {
            if (etKeyword.getText().toString().equals("") || etPHPLink.getText().toString().equals("")) {
                Toast.makeText(this,"Please fill in all fields before saving",Toast.LENGTH_LONG).show();
            } else {
                editor.putString("keyword",etKeyword.getText().toString());
                editor.putString("phpLink",etPHPLink.getText().toString());
                editor.commit();
                Toast.makeText(this,"Settings has been saved.",Toast.LENGTH_LONG).show();

                if (isListeningActivated) {
                    tvStartListening.performClick();
                }
            }
        });

        tvCopyDeviceID.setOnClickListener(view -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Device ID", tvDeviceID.getText().toString());
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this,"Device ID has been copied",Toast.LENGTH_LONG).show();
        });
    }

    private void startListening(Boolean isOn) {
        Intent startIntent = new Intent(MainActivity.this, SmsListener.class);
        startIntent.putExtra("isOn", isOn);
        startService(startIntent);

        Log.e("IsOn","" + isOn);

        editor.putBoolean("isListeningActivated",isOn);
        editor.commit();
        changeLabel();
    }

    private void startSMSService(int simID,Boolean isOn) {
        editor.putInt("simID",simID);
        editor.commit();

        Intent intent = new Intent(MainActivity.this, SMSService.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }

        Intent startIntent = new Intent(MainActivity.this, SMSService.class);
        startIntent.putExtra("isOn", isOn);
        startService(startIntent);

        isSMSActivated = !isSMSActivated;
        editor.putBoolean("isSMSActivated",isSMSActivated);
        editor.commit();
        changeLabel();

        if (isSMSActivated) {
            Toast.makeText(MainActivity.this, "SMS Sending Service is currently working", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "SMS Sending Service stopped", Toast.LENGTH_SHORT).show();
        }
    }

    private void changeLabel() {
        isSMSActivated = sp.getBoolean("isSMSActivated",false);
        isListeningActivated = sp.getBoolean("isListeningActivated",false);

        if (!isSMSActivated) {
            tvStartSending.setText("Start SMS Sending");
        } else {
            tvStartSending.setText("Stop SMS Sending");
        }

        if (!isListeningActivated) {
            tvStartListening.setText("Listen to Incoming SMS");
        } else {
            tvStartListening.setText("Stop Listening");
        }
    }
}