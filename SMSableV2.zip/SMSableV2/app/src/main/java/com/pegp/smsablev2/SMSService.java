package com.pegp.smsablev2;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SMSService extends Service {
    String channel = "Channel1";
    String currentMessageID;

    int simID;
    int current_startId;

    Boolean preventDuplicate;

    private Thread mThread;
    ScheduledExecutorService worker;
    private static final int SYNC_TIME = 5 * 1000;

    private BroadcastReceiver sendBroadcastReceiver;
    private BroadcastReceiver deliveryBroadcastReceiver;
    String SENT = "SMS_SENT";
    String DELIVERED = "SMS_DELIVERED";
    String deviceID;

    SharedPreferences sp;
    SharedPreferences.Editor editor;

    public void onCreate() {
        sp = getSharedPreferences("key", Context.MODE_PRIVATE);

        simID = sp.getInt("simID", 0);
        deviceID = sp.getString("deviceID", "-");
        RegisterReceiver();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        current_startId = startId;
        createNotificationChannel();
        startSyncService();

        if (intent.getBooleanExtra("isOn", true)) {
            Intent intent1 = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent1, PendingIntent.FLAG_IMMUTABLE);
            Notification notification = new Notification.Builder(this, channel)
                    .setContentText("Currently working as SMS Sender")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pendingIntent).build();
            startForeground(1, notification);
        } else {
            StopService();
        }

        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    channel,
                    "Foreground Service",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(notificationChannel);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private void checkSim() {
        /* 1st check if there is a sim in sim2 if none use any available */
        try {
            ArrayList<Integer> subIDS = new ArrayList<>();

            SubscriptionManager subscriptionManager = SubscriptionManager.from(getApplicationContext());
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            List<SubscriptionInfo> subsInfoList = subscriptionManager.getActiveSubscriptionInfoList();
            for (SubscriptionInfo subscriptionInfo : subsInfoList) {
                int id = subscriptionInfo.getSubscriptionId();
                subIDS.add(id);
            }

            if (subIDS.size() != 0) {
                simID = subIDS.get(subIDS.size() - 1);
                disPlayMessage("Your SIM ID is " + simID);

                checkForPendingMessage();
            } else {
                disPlayMessage("No sim card detected");
                StopService();
            }
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private void checkForPendingMessage() {
        Links application = (Links) getApplication();
        String messageApi = application.smsReceiveAPI;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, messageApi,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        Boolean error = obj.getBoolean("error");
                        Log.e("Response", response);

                        if (error) {
                            disPlayMessage("Theres an error after return the response");
                            StopService();
                        } else {
                            JSONArray arrMessages = obj.getJSONArray("result");
                            if (arrMessages.length() == 0) {
                                disPlayMessage("No message found.");
                            } else {
                                JSONObject current_obj = arrMessages.getJSONObject(0);

                                String id = current_obj.getString("id");
                                String mobileNumber = current_obj.getString("receiver");
                                String message = current_obj.getString("message");
                                preventDuplicate = false;

                                sendSMS(id, mobileNumber, message);
                            }
                        }
                    } catch (JSONException e) {
                        disPlayMessage(e.getMessage());
                        StopService();
                    }
                },
                error -> {
                    disPlayMessage(error.getMessage());
                    StopService();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("key", deviceID);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public void sendSMS(String id, String mobileNumber, String message) {
        Context mContext = this;
        currentMessageID = id;

        String SENT = "SMS_SENT";
        String DELIVERED = "SMS_DELIVERED";
        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0, new Intent(SENT), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0, new Intent(DELIVERED), PendingIntent.FLAG_IMMUTABLE);

        SmsManager sms = SmsManager.getSmsManagerForSubscriptionId(simID);
        sms.sendTextMessage(mobileNumber, null, message, sentPI, deliveredPI);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public void removeFromUnsent() {
        Links application = (Links) getApplication();
        String isSentApi = application.smsSent;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, isSentApi,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        Boolean error = obj.getBoolean("error");

                        if (error) {
                            disPlayMessage("error in updating message");
                            StopService();
                        } else {
                            disPlayMessage("Process Finished. Repeat step");
                            checkSim();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        disPlayMessage(e.getMessage());
                        StopService();
                    }
                },
                error -> {
                    disPlayMessage(error.toString());
                    StopService();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", currentMessageID);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void RegisterReceiver() {
        sendBroadcastReceiver = new BroadcastReceiver() {

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        disPlayMessage("SMS Sent");
                        removeFromUnsent();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        disPlayMessage("Generic failure");
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        disPlayMessage("No service");
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        disPlayMessage("Null PDU");
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        disPlayMessage("Radio off");
                        break;
                }
            }
        };

        deliveryBroadcastReceiver = new BroadcastReceiver() {
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        disPlayMessage("SMS Delivered");
                        break;
                    case Activity.RESULT_CANCELED:
                        disPlayMessage("SMS not delivered");
                        break;
                }
            }
        };
        registerReceiver(deliveryBroadcastReceiver, new IntentFilter(DELIVERED));
        registerReceiver(sendBroadcastReceiver, new IntentFilter(SENT));

        disPlayMessage("Nasa Broadcast ka");
    }

    public void disPlayMessage(String message) {
        Date currentTime = Calendar.getInstance().getTime();
        System.out.println("Time : " + currentTime + " Message : " + message);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void stopThread() {
        worker = null;
        if (mThread != null && mThread.isAlive()) mThread.interrupt();
    }

    private void startSyncService() {
        if (worker == null) worker = Executors.newSingleThreadScheduledExecutor();
        if (mThread == null || !mThread.isAlive()) {
            mThread = new Thread(new Runnable() {
                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
                @Override
                public void run() {
                    checkSim();
                    if (worker != null) {
                        worker.schedule(this, SYNC_TIME, TimeUnit.MILLISECONDS);
                    }
                }
            });
            mThread.start();
        }
    }

    private void StopService() {
        /* This method will close the foreground service for whatever reason */
        stopThread();

        try {
            unregisterReceiver(sendBroadcastReceiver);
            unregisterReceiver(deliveryBroadcastReceiver);
        } catch (Exception e) {

        }

        stopForeground(true);
        stopSelfResult(current_startId);
    }
}
