package com.pegp.smsablev2;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Telephony;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.telephony.SmsMessage;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SmsListener extends Service {
    String channel = "Channel2";
    String currentMessageID;
    String keyword,messageIDs;
    Long dateInstalled;

    int current_startId;

    private Thread mThread;
    ScheduledExecutorService worker;
    private static final int SYNC_TIME = 5 * 1000;

    SharedPreferences sp;
    SharedPreferences.Editor editor;

    private SMSreceiver mSMSreceiver;
    private IntentFilter mIntentFilter;

    public void onCreate() {
        sp = getSharedPreferences("key", Context.MODE_PRIVATE);
        keyword = sp.getString("keyword", "");
        dateInstalled = sp.getLong("dateInstalled",0);
        messageIDs = sp.getString("messageIDs","");

        ReceiveSMS();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public int onStartCommand(Intent intent, int flags, int startId) {
        current_startId = startId;
        createNotificationChannel();
        //startSyncService();

        if (intent.getBooleanExtra("isOn", true)) {
            Intent intent1 = new Intent(this, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent1, PendingIntent.FLAG_IMMUTABLE);
            Notification notification = new Notification.Builder(this, channel)
                    .setContentText("Currently reading for incoming message that contains "+ keyword)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pendingIntent).build();
            startForeground(2, notification);
        } else {
            StopService();
        }

        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    channel,
                    "Foreground Service",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(notificationChannel);
        }
    }

    public void StopService() {
        /* This method will close the foreground service for whatever reason */
        stopThread();
        stopForeground(true);
        stopSelfResult(current_startId);
        unregisterReceiver(mSMSreceiver);
    }

    private void ReceiveSMS() {
        mSMSreceiver = new SMSreceiver();
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(mSMSreceiver, mIntentFilter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void stopThread() {
        worker = null;
        if (mThread != null && mThread.isAlive()) mThread.interrupt();
    }

    public void disPlayMessage(String message) {
        Date currentTime = Calendar.getInstance().getTime();
        System.out.println("Time : " + currentTime + " Message : " + message);
    }
}