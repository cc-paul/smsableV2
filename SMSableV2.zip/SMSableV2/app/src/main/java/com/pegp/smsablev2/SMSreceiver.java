package com.pegp.smsablev2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class SMSreceiver extends BroadcastReceiver {
    private final String TAG = this.getClass().getSimpleName();

    SharedPreferences sp;
    SharedPreferences.Editor editor;
    String keyword;
    String phpLink;

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle extras = intent.getExtras();
        sp = context.getSharedPreferences("key", Context.MODE_PRIVATE);
        keyword = sp.getString("keyword", "");
        phpLink = sp.getString("phpLink", "");

        SmsListener listener = new SmsListener();

        if (extras != null) {
            Object[] smsextras = (Object[]) extras.get("pdus");

            for (int i = 0; i < smsextras.length; i++) {
                SmsMessage smsmsg = SmsMessage.createFromPdu((byte[]) smsextras[i]);
                String message = smsmsg.getMessageBody();
                String mobileNumber = smsmsg.getOriginatingAddress();

                if (message.contains(keyword)) {
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, phpLink,
                            response -> {

                            },
                            error -> {
                                error.toString();
                                listener.disPlayMessage(error.getMessage());
                                listener.StopService();
                            }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put("mobile", mobileNumber);
                            params.put("message", message);
                            return params;
                        }
                    };

                    RequestQueue requestQueue = Volley.newRequestQueue(context);
                    requestQueue.add(stringRequest);
                }
            }
        }
    }
}
